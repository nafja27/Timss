<p align="center"><img src="docs/logo.png" width="220" alt="مدرسة المأمون الابتدائية للبنين"></p>

# 🏝️ جزيرة التحدي — Jazeerat Al-Tahaddi

Developed for **مدرسة المأمون الابتدائية للبنين** (Al Maamoon Primary Boys School, Bahrain).

A 3D party-style board game in Arabic for **Grade 4 science and math**, aligned with **TIMSS** domains and Bahrain's national exams. Students play on a 3D island, answer questions, and compete in mini-games. Teachers track each student's progress through a pre-test, a post-test, and in-game data.

![3D board](docs/screenshots/08-board-3d.png)

## Features

**For students**
- A 3D island board with a dice, a star to collect, a shop, items, and surprise spaces.
- Solo play against the computer, or up to 4 students on one device.
- Five mini-games: quiz race, balloon pop, fast sorting, true or false, and memory cards.
- Picture-based questions (fractions, clocks, charts, food chains, magnets) with Arabic read-aloud 🔊.
- Bonus stars at the end, background music, and sound effects.

**For teachers**
- **User accounts with roles:**
  - **Admin (مدير النظام):** adds teachers, assigns their classes, and sees every class.
  - **Teacher (معلم):** sees only his own classes. He adds students by typing names or importing an Excel file, resets passwords, edits, deactivates, and prints login cards.
  - **Student (طالب):** logs in with a username and password. He can also scan the QR code on his card, or use a personal link from home.
- Passwords are stored hashed (SHA-256 with a salt). After 5 wrong attempts, that account locks for 10 minutes.
- Last-login tracking for every user.
- A 20-question **pre-test** and a parallel **post-test**, covering all 6 TIMSS Grade 4 domains.
- Every answer is tagged with its domain and skill (16 skills).
- **Adaptive practice:** each student gets more questions from his weakest skills.
- A dashboard showing class averages, pre vs post by domain, growth per student, weakest skills, and CSV exports.
- Upload your own game characters.

## Screenshots

| | | |
|---|---|---|
| ![](docs/screenshots/01-home.png) | ![](docs/screenshots/20-teachers.png) | ![](docs/screenshots/19-login-cards.png) |
| ![](docs/screenshots/04-test-fractions.png) | ![](docs/screenshots/05-test-chart.png) | ![](docs/screenshots/06-test-food-chain.png) |
| ![](docs/screenshots/07-lobby.png) | ![](docs/screenshots/09-dice-roll.png) | ![](docs/screenshots/10-board-question.png) |
| ![](docs/screenshots/11-shop.png) | ![](docs/screenshots/12-mini-balloons.png) | ![](docs/screenshots/13-mini-sorting.png) |
| ![](docs/screenshots/14-mini-memory.png) | ![](docs/screenshots/14b-mini-true-false.png) | ![](docs/screenshots/15-mini-results.png) |
| ![](docs/screenshots/16-winners.png) | ![](docs/screenshots/17-teacher-dashboard.png) | ![](docs/screenshots/18-student-detail.png) |

## Try the demo
Open `index.html` in a browser. It runs in **demo mode**, and the data is erased when the page closes.

| Role | Username | Password |
|---|---|---|
| Student | `ahmad` (also `mohammed`, `ali`, `yousif`) | `1111` (`2222`, `3333`, `4444`) |
| Teacher (class 4A) | `teacher` | `2468` |
| Admin | `admin` | `admin1234` |

## Deploy: GitHub Pages + Google Sheets

The game page is hosted on GitHub Pages. Student data is saved in a Google Sheet that you own, through Google Apps Script.

### 1. Backend (Google Sheets)
1. Create a new Google Sheet, then open **Extensions → Apps Script**.
2. Replace the contents of `Code.gs` with [`apps-script/Code.gs`](apps-script/Code.gs) and save.
3. Select the `setup` function and click **Run**. Approve the permissions (Advanced → Go to project → Allow).
4. Running setup creates the admin account **`admin` / `admin1234`**. Log in and change this password right away (🔑 كلمة المرور).
5. Go to **Deploy → New deployment → Web app**, set *Execute as: Me* and *Who has access: Anyone*, then click **Deploy**. Copy the **Web app URL**.

### 2. Connect the game
In `index.html`, find this line and paste your URL:

```js
const API_URL='';
```

### 3. Publish on GitHub Pages
Go to the repo's **Settings → Pages → Deploy from a branch → `main` / root**. Your game link will be:
`https://<your-username>.github.io/<repo-name>/`

> **Alternative without GitHub:** in Apps Script, add an HTML file named `Index`, paste the contents of `index.html` into it, and deploy. The Apps Script link then serves the game directly.

## Workflow
1. **Admin:** log in → **👥 المعلمون** → add each teacher with his classes (e.g. `4A, 4B`). Give each teacher his username and password.
2. **Teacher:** log in → choose a class → **➕ إضافة طلاب / استيراد من Excel**. Download the ready template, fill it in, and upload it. Usernames (e.g. `4a-01`) and 4-digit passwords are generated automatically if left empty.
3. Passwords are shown **only once**, right after creating or resetting. Print the login cards 🖨️ (name, username, password, QR) or download the CSV.
4. A student who forgets his password: the teacher clicks 🔑 to give him a new one.
5. Each student takes the pre-test at his first login. When ready, the teacher opens the **post-test** for his class.
6. Follow the dashboard, or export the CSVs.

## Privacy
- Use **first names only**, and class codes that are hard to guess (e.g. `MA-4B-73`).
- The code in this repo is public, but all data and accounts stay in your Google Sheet.
- Passwords are never stored in readable form. A personal link or QR works like a key, so share it only with that student's parent. Resetting a password also replaces the link.
- Follow your school's and the Ministry's policies on student data.

## Project structure
```
index.html          the full game (HTML + CSS + JS, a single file)
apps-script/Code.gs the Google Apps Script backend (accounts, data, API)
docs/screenshots/   screenshots
```

## Credits
- **إعداد القائم بأعمال مدير مساعد:** أ. نافجة الحامد
- **مديرة المدرسة:** أ. عايدة الدوسري

## Tech
three.js (r128) for the 3D board · Web Audio for music and sound effects · Web Speech API for Arabic read-aloud · Google Apps Script + Sheets for data.
